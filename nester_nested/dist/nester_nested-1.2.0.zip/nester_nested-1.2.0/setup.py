from distutils.core import setup

setup(
		name			='nester_nested',
		version			='1.2.0',
		py_modules		=['nester_nested'],
		author			='kindian',
		author_email	='patra.kailash06@gmail.com',
		url				='http://www.headfirstlabs.com',
		description		='A simple printer of nested lists',
		)
