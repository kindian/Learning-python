from setuptools import setup, find_packages

setup(
		name			='AutomateLogin',
		version			='1.0.0',
		py_modules		=['AutomateLogin'],
		author			='kindian',
		author_email	='patra.kailash06@gmail.com',
		url				='http://www.headfirstlabs.com',
		description		='A simple printer of automated lists',
                package_data = { '':['*.txt']},
		)
