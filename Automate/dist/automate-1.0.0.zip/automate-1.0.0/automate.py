def automate():
    with open('list.txt', 'r') as rl:
        for line in rl:
            print(line)
