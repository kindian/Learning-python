from distutils.core import setup

setup(
		name			='athletemodel',
		version			='1.0.0',
		py_modules		=['athletemodel'],
		author			='kindian',
		author_email	        ='patra.kailash06@gmail.com',
		description		='A list of athlete timing data',
		)
