from distutils.core import setup

setup(
		name			='athletelist',
		version			='1.0.0',
		py_modules		=['athletelist'],
		author			='kindian',
		author_email	        ='patra.kailash06@gmail.com',
		description		='A list of athlete ',
		)
